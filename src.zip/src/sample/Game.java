package sample;


import java.util.ArrayList;

// Selling physical copies
public class Game extends Good {
    protected String genre;
    protected String publisher;
    protected String developer;
    protected String release_date;

    public Game(){     }

    public Game(double price, String model, int sold, String genre, String publisher, String developer, String release_date) {
        super(price, model, sold);
        this.genre = genre;
        this.publisher = publisher;
        this.developer = developer;
        this.release_date = release_date;
    }

    public String showDetails(){
        return "Title: " + title + "\n" +
                "Genre: " + genre + "\n" +
                "Developer: " + developer + "\n" +
                "Publisher: " + publisher + "\n" +
                "Price: " + price;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public String getDeveloper() {
        return developer;
    }

    public void setDeveloper(String developer) {
        this.developer = developer;
    }

    public String getRelease_date() {
        return release_date;
    }

    public void setRelease_date(String release_date) {
        this.release_date = release_date;
    }
}
