package sample;

import java.io.Serializable;

public abstract class Good implements Serializable {
    protected double price;
    protected String title;
    protected int sold;

    public Good() {    }

    public Good(double price, String model, int sold) {
        this.price = price;
        this.title = model;
        this.sold = sold;
    }

    public abstract String showDetails();

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getModel() {
        return title;
    }

    public void setModel(String title) {
        this.title = title;
    }

    public int getSold() {
        return sold;
    }

    public void setSold(int sold) {
        this.sold = sold;
    }
}
