package sample;

import java.io.Serializable;

public class Request implements Serializable{
    private String code;
    private Game game;

    public Request() {
    }

    public Request(String code) {
        this.code = code;
    }

    public Request(String code, Game game) {
        this.code = code;
        this.game = game;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Game getStudent() {
        return game;
    }

    public void setStudent(Game game) {
        this.game = game;
    }

    @Override
    public String toString() {
        return "Request{" +
                "code='" + code + '\'' +
                ", game=" + game +
                '}';
    }
}
