package sample;

import java.io.Serializable;
import java.util.ArrayList;

public class Reply implements Serializable {
    private String code;
    private ArrayList<Game> games = null;

    public Reply(){
        games =  new ArrayList<>();
    }

    public Reply(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public ArrayList<Game> getList() {
        return games;
    }

    public void setList(ArrayList<Game> list) {
        this.games = list;
    }

    @Override
    public String toString() {
        return "Reply{" +
                "code='" + code + '\'' +
                ", list=" + games +
                '}';
    }
}
